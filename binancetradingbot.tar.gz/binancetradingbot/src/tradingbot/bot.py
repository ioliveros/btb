import sys
from db import SQLiteDB
from models import PredTable, TradingTable

from api.binance_futures import BinanceAPI


class TradingBotClient:
    def __init__(self, **config):

        self.config = config
        self.sdk = config['settings']['sdk']
        self.client = self.load_sdk_client(sdk=self.sdk)
        self.db = SQLiteDB(db=config['database']['dbname'])
        
        tf_conf = config['trading']
        self.trading_pair = tf_conf['trading_pair']
        self.amount = float(tf_conf['amount']) if tf_conf['amount'] else 0
        self.entry_price = float(tf_conf['entry_price']) if tf_conf['entry_price'] else 0
        self.target_price = float(tf_conf['target_price']) if tf_conf['target_price'] else 0

    def load_sdk_client(self, sdk):
        if sdk == 'binance':
            return BinanceAPI(**self.config)
        else:
            print(f"SDK not supported")

    def get_prices(self, symbol):
        return self.client.get_prices(symbol=symbol)

    def set_order(self, symbol:str, side:str, type:str, quantity:float, 
                                        price:float, timeInForce:str=None):
        if not self.client.supported_pairs.get(symbol, None):
            print(f"Current sdk doesn't support this pair: {symbol}")
            return

        return self.client.set_order(
                symbol=symbol, side=side, type=type, 
                quantity=quantity, price=price, timeInForce=timeInForce
            )
    
    def get_order_details(self, symbol:str, timestamp:int, orderId:int=None, 
                                origClientOrderId:str=None, recvWindow:int=None):
        return self.client.get_order_details(symbol=symbol, timestamp=timestamp, orderId=orderId)

    def get_current_position(self, symbol=str):
        return self.client.get_current_position(symbol=symbol)

    def close_order(self, symbol:str, side:str, type:str, quantity:float, reduceOnly:str=None):
        return self.client.close_order(
            symbol=symbol, side=side, type=type, 
            quantity=quantity, reduceOnly=reduceOnly
        )

    def save_requested_position(self, data:dict):
        tbl = TradingTable()
        tbl.save_requested_position(db=self.db, data=data)

    def get_predictions(self, symbol:str):
        tbl = PredTable() 
        result = tbl.get_predictions(db=self.db, symbol=symbol)
        return tbl.deserialize(result)

    def get_position_data(self, symbol:str, orderId:int=None):
        tbl = TradingTable()
        return tbl.get_position_data(db=self.db, symbol=symbol, orderId=orderId)

    def expire_requested_position(self, orderId:str):
        tbl = TradingTable()
        return tbl.expire_requested_position(db=self.db, orderId=orderId)

    def get_current_position_data(self, orderId:str):
        tbl = TradingTable()
        return tbl.get_current_position_data(db=self.db, orderId=orderId)

    def mark_position_closed(self, orderId:str):
        tbl = TradingTable()
        return tbl.mark_position_closed(db=self.db, orderId=orderId)

    def cancel_order(self, symbol:str):
        return self.client.cancel_order(symbol=symbol)

    def mark_position_cancelled(self, orderId:int):
        tbl = TradingTable()
        return tbl.mark_position_cancelled(db=self.db, orderId=orderId)