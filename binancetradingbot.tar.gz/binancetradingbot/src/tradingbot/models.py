class BaseTable:
 
    def __init__(self) -> None:
        self.feed_source = 'https://crypto-price-prediction.com/prediction_data/pred_table.csv'

    def deserialize(self, data):

        if type(data) is not list:
            data = [data]

        results = []
        for kdata in data:
            results.append({self.dmapper[k]:kdata[k] for k in kdata})
        return results

    def get_predictions(self, db:object, symbol:str):
        return db.select_one(
            f"SELECT * FROM pred_table WHERE c = '{symbol}' ORDER BY ia DESC LIMIT 1"
        )

class PredTable(BaseTable):

    def __init__(self):

        self.dmapper = {
            'id': 'id',
            'c': 'crypto',
            'p':'position',
            'tt':'trade_time(utc)',
            'et':'elapsed_time(min)',
            'ep':'entry_price',
            'tp':'target_price',
            'cp':'current_price',
            'ps':'price_spread',
            'a':'amount',
            'cpr':'current_profit',
            'dp':'daily_profit',
            'mp':'monthly_profit',
            'ia': 'inserted_at'
        }

    
class TradingTable(BaseTable):

    def __init__(self):

        self.dmapper = {
            'id': 'id',
            'oid': 'orderId',
            'coid': 'clientOrderId',
            's': 'symbol',
            'si': 'side',
            'st': 'status',
            'a': 'origQty',
            'ep': 'price',
            'tp': 'targetPrice',
            'cp': 'currentPrice',
            'up': 'unrealizedProfit',
            'im': 'initialMargin',
            'roe': 'roE',
            'ut': 'updateTime',
            'ia': 'inserted_at'
        }

    def save_requested_position(self, db:object, data:dict):
        result = db.select_one("SELECT * FROM trading_table WHERE oid = {orderId}".format(**data))
        if result:
            set_query = []
            if data.get("status", None):
                set_query.append(f"st = '{data['status']}'")
            if data.get("unrealizedProfit", None):
                set_query.append(f"up = '{data['unrealizedProfit']}'")
            if data.get("updateTime", None):
                set_query.append(f"ut = '{data['updateTime']}'")
            if data.get("currentPrice", None):
                set_query.append(f"cp = '{data['currentPrice']}'")
            if data.get("clientOrderId", None):
                set_query.append(f"coid = '{data['clientOrderId']}'")
            if data.get("initialMargin", None):
                set_query.append(f"im = '{data['initialMargin']}'")
            if data.get("roE", None):
                set_query.append(f"roe = '{data['roE']}'")
            sql = "UPDATE trading_table SET {set_query} WHERE oid = {oid}".format(
                set_query=",".join(set_query), oid=result['oid']
            )
            # update trading_table
            db.insert(sql)
        else:
            sql = "INSERT INTO trading_table (oid, coid, s, si, st, a, ep, tp, cp, ut, ia) "
            rows = {}
            for k in self.dmapper:
                row_key = self.dmapper[k]
                if not data.get(row_key, None):
                    rows[k] = ""
                else:
                    rows[k] = data[row_key]
            rows['ia'] = "strftime(\'%s\',\'now\')"
            sql += "VALUES ('{oid}', '{coid}', '{s}', '{si}', '{st}', '{a}', '{ep}', '{tp}', '{cp}', '{ut}', {ia})".format(**rows)
            db.insert(sql)

    def get_position_data(self, db:object, symbol:str, orderId:int=None):
        if not orderId:
            return db.select_one(
                f"SELECT * FROM trading_table WHERE s = '{symbol}' AND st != 'CLOSED' AND ie IS NULL ORDER BY ia DESC LIMIT 1"
            )
        else:
            return db.select_one(
                f"SELECT * FROM trading_table WHERE oid = {orderId} AND ie IS NULL ORDER BY ia DESC LIMIT 1"
            )

    def expire_requested_position(self, db:object, orderId:int):
        return db.insert(f"UPDATE trading_table SET ie = 1 WHERE oid = {orderId}")

    def get_current_position_data(seld, db:object, orderId:int=None):
        return db.select_one(
                f"SELECT * FROM trading_table WHERE oid = {orderId} AND ie IS NULL ORDER BY ia DESC LIMIT 1"
            )

    def mark_position_closed(seld, db:object, orderId:int=None):
        return db.insert(
                f"UPDATE trading_table SET st = 'CLOSED' , ie = 2 WHERE oid = {orderId}"
            )

    def mark_position_cancelled(seld, db:object, orderId:int=None):
        return db.insert(
                f"UPDATE trading_table SET st = 'CANCELED' , ie = 2 WHERE oid = {orderId}"
            )