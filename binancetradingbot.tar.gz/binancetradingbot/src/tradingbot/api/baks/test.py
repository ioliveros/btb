from binance.cm_futures import CMFutures

cm_futures_client = CMFutures()

print(cm_futures_client.time())
cm_futures_client = CMFutures(key='HpfGZmbyntlcR57bvWgedja69iT7P0sIvdt4EEBI5rTBI4wFdWl4FjWMnBFu8N8C', 
        secret='AteMO3NGehs0dLja84Pa6U29KuSZXCWSQ0M8fKxxfU9KZbQdyTACIIX3atObkWEJ')

print(cm_futures_client.account())


def short():
    # Post a new order
    params = {
        'symbol': 'BTCUSDT',
        'side': 'SELL',
        'type': 'LIMIT',
        'timeInForce': 'GTC',
        'quantity': 0.002,
        'price': 59808
    }

def long():
    pass
