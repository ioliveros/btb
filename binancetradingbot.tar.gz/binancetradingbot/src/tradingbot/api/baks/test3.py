import logging
import pandas as pd
from binance.client import Client


client = Client(
        api_key="98825baa84609a80cf875c6e51b21e63eda42759a68a92680240522c3b9f43f5",
        api_secret="635fd956856fff8619b58f6e6967a676a9c5cd27d5f02a9116d934ee1c12e480",
        testnet=True
    )


logging.basicConfig(level=logging.DEBUG)
balance = client.futures_account_balance()
account = client.futures_account()

print(balance)

client.futures_change_leverage(symbol='BTCUSDT', leverage=1)

def order(symbol, side=None, type=None, price=None, quantity=None, timeInForce=None, stopPrice=None, closePosition=None):

    if not timeInForce:
        timeInForce = 'GTC'

    if type == "LIMIT":
        result = client.futures_create_order(symbol=symbol, type=type, timeInForce=timeInForce, price=price, side=side, quantity=quantity)
    elif type == "MARKET":
        result = client.futures_create_order(symbol=symbol, type=type, side=side, quantity=quantity)
    elif type == "STOP_MARKET":
        result = client.futures_create_order(symbol=symbol, side='BUY', type='STOP_MARKET', stopPrice=stopPrice, closePosition=closePosition)

    print(result)


if __name__ == "__main__":

    # set limit
    #order(symbol="BTCUSDT", side="BUY", type="LIMIT", price=24632.1, quantity=0.203)
    # set market
    #order(symbol="BTCUSDT", side="BUY", type="MARKET", quantity=0.203)
    # set stop loss
    #buyorder=order(symbol="BTCUSDT", side='BUY', type='STOP_MARKET', stopPrice=24690, closePosition='true')
    #client.futures_create_order(symbol="BTCUSDT", type="LIMIT", side="BUY", price=245680, timeInForce='GTC', stopPrice=24680)
    #client.futures_create_order(symbol='BTCUSDT',side='BUY',type='STOP_MARKET',stopPrice='24554',closePosition='true') 
    #client.futures_create_order(symbol='BTCUSDT', side='BUY', type='LIMIT', closePosition='true')
    #client.futures_create_order(symbol='BTCUSDT', side='SELL', type='STOP_MARKET', timeInForce='GTC', quantity=0.203, stopPrice=24580, workingType='MARK_PRICE')
    #client.futures_create_order(symbol='BTCUSDT', side='BUY', type='TAKE_PROFIT_MARKET', timeInForce='GTC', quantity=0.203, stopPrice=24590, workingType='MARK_PRICE')
    #client.futures_create_order(symbol='BTCUSDT', side='BUY', type='STOP_MARKET', stopPrice=24640, closePosition='true')
    client.futures_create_order(symbol='BTCUSDT', side='SELL', type='MARKET', quantity=0.203, reduceOnly='true')
    #client.futures_create_order(symbol='BTCUSDT', side='BUY', type='LIMIT', quantity=0.203, price=24647.13, timeInForce='GTC')
    #params = {'symbol': 'BTCUSDT', 'side': 'BUY', 'type': 'LIMIT', 'quantity': 0.203, 'price': 24647.66, 'timeInForce': 'GTC'}
    #client.futures_create_order(**params)
    #print(client.futures_get_order(symbol='BTCUSDT', orderId=3293381788, timestamp=1676993310500))
    #client.enable_subaccount_futures()
    #print(client.get_subaccount_futures_positionrisk(symbol='BTCUSDT', email='ian.t.oliveros@gmail.com'))
    #positions = client.futures_account()['positions']
    #for item in positions:
    #    if item['symbol'] != 'BTCUSDT': continue
    #    print(item)
    #    break
