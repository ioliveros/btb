import pandas as pd
from binance.client import Client

client = Client(
        api_key="HpfGZmbyntlcR57bvWgedja69iT7P0sIvdt4EEBI5rTBI4wFdWl4FjWMnBFu8N8C", 
        api_secret="AteMO3NGehs0dLja84Pa6U29KuSZXCWSQ0M8fKxxfU9KZbQdyTACIIX3atObkWEJ"
    )

client.futures_symbol_ticker(symbol='BTCUSDT')

'''
df = pd.DataFrame(client.futures_historical_klines(
    symbol='BTCUSDT',
    interval='1d',
    start_str='2023-01-01',
    end_str='2023-02-21'
))
df = df.iloc[:, :6]
df.columns = ['date', 'open', 'high', 'low', 'close', 'volume']
df['date'] = pd.to_datetime(df['date'], unit='ms')
for col in df.columns[1:]:
    df[col] = pd.to_numeric(df[col])
print(df.head())

'''


df = pd.DataFrame(client.futures_order_book(symbol='BTCUSDT'))
print(df[['bids', 'asks']].head())
