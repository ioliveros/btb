#!/usr/bin/python3

import time

while True:
    print(f"serve..")
    time.sleep(10)
